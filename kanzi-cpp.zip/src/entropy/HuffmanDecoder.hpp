/*
Copyright 2011-2021 Frederic Langlet
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
you may obtain a copy of the License at

                http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#ifndef _HuffmanDecoder_
#define _HuffmanDecoder_

#include "HuffmanCommon.hpp"
#include "../EntropyDecoder.hpp"


namespace kanzi
{

   // Implementation of a static Huffman encoder.
   // Uses in place generation of canonical codes instead of a tree
   class HuffmanDecoder : public EntropyDecoder
   {
   public:
       HuffmanDecoder(InputBitStream& bitstream, int chunkSize=HuffmanCommon::MAX_CHUNK_SIZE) THROW;

       ~HuffmanDecoder() { _dispose(); delete[] _buffer; }

       int decode(byte block[], uint blkptr, uint len);

       InputBitStream& getBitStream() const { return _bitstream; }

       void dispose() { _dispose(); }

   private:
       static const int DECODING_BATCH_SIZE = 14; // ensures decoding table fits in L1 cache
       static const int TABLE_MASK = (1 << DECODING_BATCH_SIZE) - 1;

       InputBitStream& _bitstream;
       uint _codes[256];
       uint _alphabet[256];
       uint16 _sizes[256];
       uint16 _table[TABLE_MASK + 1]; // decoding table: code -> size, symbol
       int _chunkSize;
       byte* _buffer;
       uint _bufferSize;

       int readLengths() THROW;

       void buildDecodingTable(int count);

       bool reset();

       void _dispose() {}

       byte decodeSymbol(byte*& p, uint& st, int& bits);
   };


   inline byte HuffmanDecoder::decodeSymbol(byte*& p, uint& st, int& bits)
   {
       const int code = _table[(st >> (bits - DECODING_BATCH_SIZE)) & TABLE_MASK];
       //std::cout << (code & 0xFF) << " " << ((st >> (bits - DECODING_BATCH_SIZE)) & TABLE_MASK) << std::endl;
       bits -= (code & 0xFF);

       if (bits < 16) {
           st = (st << 8) | uint(*p++);
           st = (st << 8) | uint(*p++);
           bits += 16;
       }

       return byte(code >> 8);
   }
}
#endif
