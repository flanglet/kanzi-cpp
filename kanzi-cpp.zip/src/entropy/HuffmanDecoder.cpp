
/*
Copyright 2011-2021 Frederic Langlet
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
you may obtain a copy of the License at

                http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

#include <algorithm>
#include <cstring>
#include <sstream>
#include "HuffmanDecoder.hpp"
#include "EntropyUtils.hpp"
#include "ExpGolombDecoder.hpp"
#include "../BitStreamException.hpp"

using namespace kanzi;
using namespace std;

// The chunk size indicates how many bytes are encoded (per block) before
// resetting the frequency stats.
HuffmanDecoder::HuffmanDecoder(InputBitStream& bitstream, int chunkSize) THROW : _bitstream(bitstream)
{
    if (chunkSize < 1024)
        throw invalid_argument("Huffman codec: The chunk size must be at least 1024");

    if (chunkSize > HuffmanCommon::MAX_CHUNK_SIZE) {
        stringstream ss;
        ss << "Huffman codec: The chunk size must be at most " << HuffmanCommon::MAX_CHUNK_SIZE;
        throw invalid_argument(ss.str());
    }

    _chunkSize = chunkSize;
    _buffer = new byte[0];
    _bufferSize = 0;
    reset();
}

bool HuffmanDecoder::reset()
{
    // Default lengths & canonical codes
    for (int i = 0; i < 256; i++) {
        _codes[i] = i;
        _sizes[i] = 8;
    }

    memset(_alphabet, 0, sizeof(_alphabet));
    memset(_table, 0, sizeof(_table));
    return true;
}

int HuffmanDecoder::readLengths() THROW
{
    const int count = EntropyUtils::decodeAlphabet(_bitstream, _alphabet);

    if (count == 0)
        return 0;

    ExpGolombDecoder egdec(_bitstream, true);
    int curSize = 2;

    // Read lengths from bitstream
    for (int i = 0; i < count; i++) {
        const uint s = _alphabet[i];

        if (s > 255) {
            string msg = "Invalid bitstream: incorrect Huffman symbol ";
            msg += to_string(s);
            throw BitStreamException(msg, BitStreamException::INVALID_STREAM);
        }

        _codes[s] = 0;
        curSize += int8(egdec.decodeByte());

        if ((curSize <= 0) || (curSize > HuffmanCommon::MAX_SYMBOL_SIZE)) {
            stringstream ss;
            ss << "Invalid bitstream: incorrect size " << int(curSize);
            ss << " for Huffman symbol " << s;
            throw BitStreamException(ss.str(), BitStreamException::INVALID_STREAM);
        }

        _sizes[s] = uint16(curSize);
    }

    // Create canonical codes
    if (HuffmanCommon::generateCanonicalCodes(_sizes, _codes, _alphabet, count) < 0) {
        stringstream ss;
        ss << "Could not generate Huffman codes: max code length (";
        ss << HuffmanCommon::MAX_SYMBOL_SIZE;
        ss << " bits) exceeded";
        throw BitStreamException(ss.str(), BitStreamException::INVALID_STREAM);
    }

    // Build decoding tables
    buildDecodingTable(count);
    return count;
}

// max(CodeLen) must be <= MAX_SYMBOL_SIZE
void HuffmanDecoder::buildDecodingTable(int count)
{
    memset(_table, 0, sizeof(_table));
    int length = 0;

    for (int i = 0; i < count; i++) {
        const uint16 s = uint16(_alphabet[i]);

        if (_sizes[s] > length)
            length = _sizes[s];

        // code -> size, symbol
        const uint16 val = (s << 8) | _sizes[s];

        // All DECODING_BATCH_SIZE bit values read from the bit stream and
        // starting with the same prefix point to symbol s
        uint idx = _codes[s] << (DECODING_BATCH_SIZE - length);
        const uint end = idx + (1 << (DECODING_BATCH_SIZE - length));

        while (idx < end)
            _table[idx++] = val;
    }
}

int HuffmanDecoder::decode(byte block[], uint blkptr, uint count)
{
    if (count == 0)
        return 0;

    uint startChunk = blkptr;
    const uint end = blkptr + count;

    while (startChunk < end) {    
        const uint sizeChunk = min(uint(_chunkSize), end - startChunk);
        const int alphabetSize = readLengths();

        if (alphabetSize <= 0)
            return startChunk - blkptr;

        if (alphabetSize == 1) {
            // Shortcut for chunks with only one symbol
            memset(&block[startChunk], _alphabet[0], size_t(sizeChunk));
            startChunk += sizeChunk;
            continue;
        }

       // Read chunk size
       const uint sz = uint(EntropyUtils::readVarInt(_bitstream) & (HuffmanCommon::MAX_CHUNK_SIZE - 1));

       // Read initial states
       uint st0 = uint(_bitstream.readBits(24));
       uint st1 = uint(_bitstream.readBits(24));
       uint st2 = uint(_bitstream.readBits(24));
       uint st3 = uint(_bitstream.readBits(24));

       // Read encoded data from bitstream
       if (sz != 0) {
            if (_bufferSize < sz) {
               delete[] _buffer;
               _bufferSize = max(sz + (sz >> 3), uint(256));
               _buffer = new byte[_bufferSize];
           }

           _bitstream.readBits(&_buffer[0], 8 * sz);
       }

       byte* p = &_buffer[0];
       byte* out = &block[startChunk];
       const uint sizeChunk4 = sizeChunk & -4;
       int bits0 = st0 & 0xFF;
       int bits1 = st1 & 0xFF;
       int bits2 = st2 & 0xFF;
       int bits3 = st3 & 0xFF;
       st0 >>= 8;
       st1 >>= 8;
       st2 >>= 8;
       st3 >>= 8;

       for (uint i = 0; i < sizeChunk4; i += 4) {
            out[i + 0] = decodeSymbol(p, st3, bits3);
                        cout <<  std::dec << i << " " << bits3 << " " <<  std::hex <<st3 << endl; 
            out[i + 1] = decodeSymbol(p, st2, bits2);
            out[i + 2] = decodeSymbol(p, st1, bits1);
            out[i + 3] = decodeSymbol(p, st0, bits0);
        }

       for (uint i = sizeChunk4; i < sizeChunk; i++)
           out[i] = *p++;

        startChunk += sizeChunk;
    }

    return count;
}
